export interface Treasure {
    id: number;
    name: string;
    location: string;
};