import { Treasure } from './treasures/treasures';

export const treasures: Treasure[] = [{
    id: 1,
    name: 'Windstorm Gold Staff',
    location: 'Tree behind home',
}];