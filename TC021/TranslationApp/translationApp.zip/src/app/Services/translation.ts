export interface Translation {
    translation: string
}
